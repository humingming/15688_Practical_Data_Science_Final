__author__ = 'humin_000'

# QSTK Imports
import QSTK.qstkutil.qsdateutil as du
# import QSTK.qstkutil.tsutil as tsu
import QSTK.qstkutil.DataAccess as da

# Third Party Imports
import datetime as dt
# import matplotlib.pyplot as plt
# import pandas as pd
import numpy as np
import math as mt

def simulator(dt_start, dt_end, ls_symbols, lf_locations):
    # We need closing prices so the timestamp should be hours=16.
    dt_timeofday = dt.timedelta(hours=16)
    # Get a list of trading days between the start and the end.
    ldt_timestamps = du.getNYSEdays(dt_start, dt_end, dt_timeofday)
    # Creating an object of the dataaccess class with Yahoo as the source.
    c_dataobj = da.DataAccess('Yahoo')
    # Keys to be read from the data, it is good to read everything in one go.
    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']

    # Reading the data, now d_data is a dictionary with the keys above.
    # Timestamps and symbols are the ones that were specified before.
    ldf_data = c_dataobj.get_data(ldt_timestamps, ls_symbols, ls_keys)
    d_data = dict(zip(ls_keys, ldf_data))

    # Filling the data for NAN
    for s_key in ls_keys:
        d_data[s_key] = d_data[s_key].fillna(method='ffill')
        d_data[s_key] = d_data[s_key].fillna(method='bfill')
        d_data[s_key] = d_data[s_key].fillna(1.0)

    # Getting the numpy ndarray of close prices.
    na_price = d_data['close'].values

    # initial shares
    lf_shares = lf_locations / na_price[0, :]

    # calculate portfolio
    lf_portfolio = np.zeros(len(ldt_timestamps))
    for x in range(len(ls_symbols)):
#         print 'na_price[:, x]: ', na_price[:, x]
#         print 'lf_shares[x]', lf_shares[x]
        lf_portfolio += na_price[:, x] * lf_shares[x]
#         print 'lf_portfolio: ', lf_portfolio

    lf_portfolio_ret = np.zeros(len(ldt_timestamps))
    for y in range(len(lf_portfolio_ret)):
        if(y == 0):
            lf_portfolio_ret[y] = 0.0
        else:
            lf_portfolio_ret[y] = lf_portfolio[y] / lf_portfolio[y - 1] - 1

    vol = np.std(lf_portfolio_ret)
    daily_ret = np.average(lf_portfolio_ret)
    sharpe = daily_ret / vol * mt.sqrt(252)
    cum_ret = lf_portfolio[-1]

    return vol, daily_ret, sharpe , cum_ret

def main():
    dt_start = dt.datetime(2011, 1, 1)
    dt_end = dt.datetime(2011, 12, 31)
    ls_symbols = ['AAPL', 'GLD', 'GOOG', 'XOM']
    lf_locations = [0.4, 0.4, 0.0, 0.2]
    print 'start date: ', dt_start
    print 'end date:', dt_end
    print 'symbols: ', ls_symbols
    print 'locations: ', lf_locations
    vol, daily_ret, sharpe, cum_ret = simulator(dt_start, dt_end, ls_symbols, lf_locations)
    print 'vol: ', vol
    print 'daily_ret: ', daily_ret
    print 'sharpe: ', sharpe
    print 'cum_ret: ', cum_ret

    print '--------------------------------------------------'

    dt_start = dt.datetime(2010, 1, 1)
    dt_end = dt.datetime(2010, 12, 31)
    ls_symbols = ['AXP', 'HPQ', 'IBM', 'HNZ']
    lf_locations = [0.0, 0.0, 0.0, 1.0]
    print 'start date: ', dt_start
    print 'end date:', dt_end
    print 'symbols: ', ls_symbols
    print 'locations: ', lf_locations
    vol, daily_ret, sharpe, cum_ret = simulator(dt_start, dt_end, ls_symbols, lf_locations)
    print 'vol: ', vol
    print 'daily_ret: ', daily_ret
    print 'sharpe: ', sharpe
    print 'cum_ret: ', cum_ret

if __name__ == '__main__':
    main()
