__author__ = 'humin_000'

# QSTK Imports
# import QSTK.qstkutil.qsdateutil as du
# import QSTK.qstkutil.tsutil as tsu
# import QSTK.qstkutil.DataAccess as da

# Third Party Imports
import datetime as dt
# import matplotlib.pyplot as plt
# import pandas as pd
import numpy as np
# import math as mt
import simulator as sm

def optimizer(ls_symbols, dt_start=dt.datetime(2010, 1, 1), dt_end=dt.datetime(2010, 12, 31)):
    sharpe_ret = 0.0
    lf_locations_ret = np.zeros(len(ls_symbols))
    for equityi in range(0, 101, 10):
        for equityj in range(0, 101, 10):
            if(equityi + equityj > 100):
                break
            for equityk in range(0, 101, 10):
                if(equityi + equityj + equityk > 100):
                    break
                for equityl in range(0, 101, 10):
                    if(equityi + equityj + equityk + equityl != 100):
                        continue

                    lf_locations = [equityi/100.0, equityj/100.0, equityk/100.0, equityl/100.0,]

#                     print 'dt_start: ', dt_start
#                     print 'dt_end: ', dt_end
#                     print 'ls_symbols: ', ls_symbols
#                     print 'lf_locations: ', lf_locations
                    vol, daily_ret, sharpe, cum_ret = sm.simulator(dt_start, dt_end, ls_symbols, lf_locations)

#                     print 'sharpe: ', sharpe
                    if(sharpe > sharpe_ret):
                        sharpe_ret = sharpe
                        lf_locations_ret = lf_locations
    return sharpe_ret, lf_locations_ret

def main():
    ls_symbols = ['C', 'GS', 'IBM', 'HNZ']
    print 'symbols: ', ls_symbols
    sharpe, lf_locations = optimizer(ls_symbols)
    print 'location: ', lf_locations
    print 'sharpe: ', sharpe

if __name__ == '__main__':
    main()
