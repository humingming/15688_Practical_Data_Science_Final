__author__ = 'humin_000'

# QSTK Imports
import QSTK.qstkutil.qsdateutil as du
import QSTK.qstkutil.DataAccess as da
# Third Party Imports
import datetime as dt
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def main():
    dt_start = dt.datetime(2010, 1, 1)
    dt_end = dt.datetime(2010, 12, 31)
    # ls_symbols = ['AAPL', 'GOOG', 'IBM', 'MSFT']
    ls_symbols = ['AAPL']
    # We need closing prices so the timestamp should be hours=16.
    dt_timeofday = dt.timedelta(hours=16)
    # Get a list of trading days between the start and the end.
    ldt_timestamps = du.getNYSEdays(dt_start, dt_end, dt_timeofday)
    # Creating an object of the dataaccess class with Yahoo as the source.
    c_dataobj = da.DataAccess('Yahoo')
    # Keys to be read from the data, it is good to read everything in one go.
    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']

    # Reading the data, now d_data is a dictionary with the keys above.
    # Timestamps and symbols are the ones that were specified before.
    ldf_data = c_dataobj.get_data(ldt_timestamps, ls_symbols, ls_keys)
    d_data = dict(zip(ls_keys, ldf_data))

    # Filling the data for NAN
    for s_key in ls_keys:
        d_data[s_key] = d_data[s_key].fillna(method='ffill')
        d_data[s_key] = d_data[s_key].fillna(method='bfill')
        d_data[s_key] = d_data[s_key].fillna(1.0)

    # Getting the numpy ndarray of close prices.
    na_price = d_data['close'].values

    na_bollingerbands = (na_price - pd.rolling_mean(na_price, 20)) / pd.rolling_std(na_price, 20)

    print 'ls_symbols', ls_symbols
    for x in range(len(ldt_timestamps)):
        print ldt_timestamps[x], na_bollingerbands[x]

    na_mean = pd.rolling_mean(na_price, 20)
    na_upperbands = na_mean + pd.rolling_std(na_price, 20)
    na_lowerbands = na_mean - pd.rolling_std(na_price, 20)

    plt.clf()
    plt.plot(ldt_timestamps, na_price)
    plt.plot(ldt_timestamps, pd.rolling_mean(na_price, 20))
    plt.plot(ldt_timestamps, na_upperbands)
    plt.plot(ldt_timestamps, na_lowerbands)
    x = np.array(ldt_timestamps)
    y1 = np.array(na_upperbands).reshape(len(ldt_timestamps))
    y2 = np.array(na_lowerbands).reshape(len(ldt_timestamps))

    # plt.fill_between(ldt_timestamps, na_upperbands, na_lowerbands, facecolor='gray', alpha=0.2)
    plt.fill_between(x, y1, y2, facecolor='gray', alpha=0.2)
    plt.legend([ls_symbols, 'Avg', 'upper band', 'lower band'], loc='upper left')
    plt.xlabel('Date')
    plt.ylabel('Adjusted Close')
    plt.savefig('bollingerbands1.pdf', format='pdf')

    plt.clf()
    plt.plot(ldt_timestamps, na_bollingerbands)
    plt.plot(ldt_timestamps, (na_upperbands - na_mean) / pd.rolling_std(na_price, 20))
    plt.plot(ldt_timestamps, (na_lowerbands - na_mean) / pd.rolling_std(na_price, 20))
    plt.axhline(y=1, color='gray')
    plt.axhline(y=-1, color='gray')
    plt.xlabel('Date')
    plt.ylabel('Bollinger Feature')
    plt.savefig('bollingerbands2.pdf', format='pdf')

if __name__ == '__main__':
    main()
