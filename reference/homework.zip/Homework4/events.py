__author__ = 'humin_000'

import sys
import numpy as np
import copy
import csv
import QSTK.qstkutil.qsdateutil as du
import datetime as dt
import QSTK.qstkutil.DataAccess as da

def find_events(ls_symbols, d_data, orderFile):
    ''' Finding the event dataframe '''
    df_close = d_data['actual_close']

    print "Finding Events"

    # Creating an empty dataframe
    df_events = copy.deepcopy(df_close)
    df_events = df_events * np.NAN

    # Time stamps for the event range
    ldt_timestamps = df_close.index
    count = 0

    # order.csv
    writer = csv.writer(open(orderFile, 'wb'), delimiter=',')

    for s_sym in ls_symbols:
        for i in range(1, len(ldt_timestamps) - 5):
            # Calculating the returns for this timestamp
            f_symprice_today = df_close[s_sym].ix[ldt_timestamps[i]]
            f_symprice_yest = df_close[s_sym].ix[ldt_timestamps[i - 1]]

            # Event is found if price[t-1] >= 5.0 && price[t] < 5.0
            if f_symprice_today < 10.0 and f_symprice_yest >= 10.0:
                df_events[s_sym].ix[ldt_timestamps[i]] = 1
                count = count + 1

                # output order.csv
                time_buy = ldt_timestamps[i]
                time_sell = ldt_timestamps[-1]
                if (i + 5) < len(ldt_timestamps):
                    time_sell = ldt_timestamps[i + 5]

                writer.writerow([time_buy.year, time_buy.month, time_buy.day, s_sym, 'BUY', 100])
                writer.writerow([time_sell.year, time_sell.month, time_sell.day, s_sym, 'SELL', 100])

    return df_events, count

def main():
    # read parameters
    if len(sys.argv) != 2:
        print "Please input essential parameters in the command line."
        print "For example events.py order.csv"
        sys.exit(0)

    # order.csv
    orderFile = sys.argv[1]

    dt_start = dt.datetime(2008, 1, 1)
    dt_end = dt.datetime(2009, 12, 31)
    ldt_timestamps = du.getNYSEdays(dt_start, dt_end, dt.timedelta(hours=16))

    c_dataobj = da.DataAccess('Yahoo')
    ls_symbols2012 = c_dataobj.get_symbols_from_list('sp5002012')

    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']
    ldf_data2012 = c_dataobj.get_data(ldt_timestamps, ls_symbols2012, ls_keys)
    d_data2012 = dict(zip(ls_keys, ldf_data2012))

    for s_key in ls_keys:
        d_data2012[s_key] = d_data2012[s_key].fillna(method='ffill')
        d_data2012[s_key] = d_data2012[s_key].fillna(method='bfill')
        d_data2012[s_key] = d_data2012[s_key].fillna(1.0)

    df_events, count = find_events(ls_symbols2012, d_data2012, orderFile)

if __name__ == '__main__':
    main()
