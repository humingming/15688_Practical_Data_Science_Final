__author__ = 'humin_000'

import numpy as np
import copy
import QSTK.qstkutil.qsdateutil as du
import datetime as dt
import QSTK.qstkutil.DataAccess as da
import QSTK.qstkstudy.EventProfiler as ep
import pandas as pd

def find_events(ls_symbols, d_data):
    ''' Finding the event dataframe '''
    df_close = d_data['close']

    print "Finding Events"

    # Creating an empty dataframe
    df_events = copy.deepcopy(df_close)
    df_events = df_events * np.NAN

    df_bollinger = copy.deepcopy(df_events)
    df_bollinger = (df_close - pd.rolling_mean(df_close, 20)) / pd.rolling_std(df_close, 20)

    # Time stamps for the event range
    ldt_timestamps = df_close.index
    count = 0

    for s_sym in ls_symbols:
        for i in range(1, len(ldt_timestamps)):
            # Calculating the bollinger value for this timestamp
            f_symbollinger_today = df_bollinger[s_sym].ix[ldt_timestamps[i]]
            f_symbollinger_yest = df_bollinger[s_sym].ix[ldt_timestamps[i-1]]
            f_spxbollinger_today = df_bollinger['SPY'].ix[ldt_timestamps[i]]

            # Event is found if Bollinger value for the equity today <= -2.0
            #                   Bollinger value for the equity yesterday >= -2.0
            #                   Bollinger value for SPY today >= 1.0
            if f_symbollinger_today <= -2.0 and f_symbollinger_yest >= -2.0 and f_spxbollinger_today >= 1.0:
                df_events[s_sym].ix[ldt_timestamps[i]] = 1
                count = count + 1

    return df_events, count

def main():
    dt_start = dt.datetime(2008, 1, 1)
    dt_end = dt.datetime(2009, 12, 31)
    ldt_timestamps = du.getNYSEdays(dt_start, dt_end, dt.timedelta(hours=16))

    c_dataobj = da.DataAccess('Yahoo')
    ls_symbols = c_dataobj.get_symbols_from_list('sp5002012')
    ls_symbols.append('SPY')

    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']
    ldf_data = c_dataobj.get_data(ldt_timestamps, ls_symbols, ls_keys)
    d_data = dict(zip(ls_keys, ldf_data))

    for s_key in ls_keys:
        d_data[s_key] = d_data[s_key].fillna(method='ffill')
        d_data[s_key] = d_data[s_key].fillna(method='bfill')
        d_data[s_key] = d_data[s_key].fillna(1.0)

    df_events, count = find_events(ls_symbols, d_data)
    print "The total count is", count

    print "Creating Bollinger Band Indicator Study 2012"
    ep.eventprofiler(df_events, d_data, i_lookback=20, i_lookforward=20,
                s_filename='MyBollingerEventStudy.pdf', b_market_neutral=True, b_errorbars=True,
                s_market_sym='SPY')

if __name__ == '__main__':
    main()