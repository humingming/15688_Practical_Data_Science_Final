__author__ = 'humin_000'

import sys
import csv
import datetime as dt
import numpy as np
import math as mt
import matplotlib.pyplot as plt
# QSTK Imports
import QSTK.qstkutil.qsdateutil as du
import QSTK.qstkutil.DataAccess as da

def main():
    # read parameters
    if len(sys.argv) != 3:
        print "Please input essential parameters in the command line."
        print "For example analyze.py value.csv benchmark"
        sys.exit(0)

    # value.csv
    valueFile = sys.argv[1]

    # banchmark
    s_symbol = sys.argv[2]

    # read value.csv
    lf_portfolio = []
    ld_dates = []
    reader = csv.reader(open(valueFile, 'rU'), delimiter=',')
    for row in reader:
        # add symbol
        lf_portfolio.append(float(row[3]))
        # add order date
        ld_dates.append(dt.datetime(int(row[0]), int(row[1]), int(row[2])))

    # create np portfolio
    na_portfolio = np.zeros((len(ld_dates), 1))
    for x in range(len(ld_dates)):
        na_portfolio[x, 0] = lf_portfolio[x]

    # read market data
    # We need closing prices so the timestamp should be hours=16.
    dt_timeofday = dt.timedelta(hours=16)
    # Get a list of trading days between the start and the end.
    ldt_timestamps = du.getNYSEdays(ld_dates[0], ld_dates[-1] + dt.timedelta(days=1), dt_timeofday)
    # Creating an object of the dataaccess class with Yahoo as the source.
    c_dataobj = da.DataAccess('Yahoo')
    # Keys to be read from the data, it is good to read everything in one go.
    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']
    ls_symbols = [s_symbol]
    # Reading the data, now d_data is a dictionary with the keys above.
    # Timestamps and symbols are the ones that were specified before.
    ldf_data = c_dataobj.get_data(ldt_timestamps, ls_symbols, ls_keys)
    d_data = dict(zip(ls_keys, ldf_data))

    # Filling the data for NAN
    for s_key in ls_keys:
        d_data[s_key] = d_data[s_key].fillna(method='ffill')
        d_data[s_key] = d_data[s_key].fillna(method='bfill')
        d_data[s_key] = d_data[s_key].fillna(1.0)

    # Getting the numpy ndarray of close prices.
    na_price = d_data['close'].values

    lf_portfolio_ret = np.zeros(len(ldt_timestamps))
    lf_benchmark_ret = np.zeros(len(ldt_timestamps))
    for y in range(len(lf_portfolio_ret)):
        if(y == 0):
            lf_portfolio_ret[y] = 0.0
            lf_benchmark_ret[y] = 0.0
        else:
            lf_portfolio_ret[y] = na_portfolio[y, 0] / na_portfolio[y - 1, 0] - 1
            lf_benchmark_ret[y] = na_price[y, 0] / na_price[y - 1, 0] - 1

    vol_p = np.std(lf_portfolio_ret)
    daily_ret_p = np.average(lf_portfolio_ret)
    sharpe_p = daily_ret_p / vol_p * mt.sqrt(252)
    cum_ret_p = na_portfolio[-1, 0] / na_portfolio[0, 0]

    vol_b = np.std(lf_benchmark_ret)
    daily_ret_b = np.average(lf_benchmark_ret)
    sharpe_b = daily_ret_b / vol_b * mt.sqrt(252)
    cum_ret_b = na_price[-1, 0] / na_price[0, 0]

    print 'Details of the Performance of the portfolio :'
    print 'Data Range :', ldt_timestamps[0], 'to', ldt_timestamps[-1]
    print 'Sharpe Ratio of Fund :', sharpe_p
    print 'Sharpe Ratio of $SPX :', sharpe_b
    print 'Total Return of Fund :', cum_ret_p
    print 'Total Return of $SPX :', cum_ret_b
    print 'Standard Deviation of Fund :', vol_p
    print 'Standard Deviation of $SPX :', vol_b
    print 'Average Daily Return of Fund :', daily_ret_p
    print 'Average Daily Return of $SPX :', daily_ret_b

    ls_plot_symbols = [s_symbol, 'Portfolio']
    na_plot_value = np.zeros((len(ldt_timestamps), 2))
    for x in range(len(ldt_timestamps)):
        na_plot_value[x, 0] = lf_portfolio[0] * na_price[x, 0] / na_price[0, 0]
        na_plot_value[x, 1] = na_portfolio[x, 0]

    plt.clf()
    plt.plot(ldt_timestamps, na_plot_value)
    plt.legend(ls_plot_symbols, loc='upper left')
    plt.ylabel('Fund Value')
    plt.xlabel('Date')
    plt.savefig('marketsimBollingerAnalyze.pdf', format='pdf')

if __name__ == '__main__':
    main()
