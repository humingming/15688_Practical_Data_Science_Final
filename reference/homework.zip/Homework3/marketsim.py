__author__ = 'humin_000'
import sys
import csv
import datetime as dt
import numpy as np
# QSTK Imports
import QSTK.qstkutil.qsdateutil as du
import QSTK.qstkutil.DataAccess as da

def main():
    # read parameters
    if len(sys.argv) != 4:
        print "Please input essential parameters in the command line."
        print "For example marketsim.py initialMoney order.csv value.csv"
        sys.exit(0)

    # input initial money
    initialMoney = float(sys.argv[1])
    # value.csv
    valueFile = sys.argv[3]

    # read order.csv
    csvFile = sys.argv[2]
    ls_symbols = []
    ld_dates = []
    reader = csv.reader(open(csvFile, 'rU'), delimiter=',')
    for row in reader:
        # add symbol
        ls_symbols.append(row[3])
        # add order date
        ld_dates.append(dt.datetime(int(row[0]), int(row[1]), int(row[2])))

    # remove duplicates
    ls_symbols_unique = list(set(ls_symbols))
    ld_dates_unique = list(set(ld_dates))
    # sort the date
    ld_dates_unique.sort()

    # read market data
    # We need closing prices so the timestamp should be hours=16.
    dt_timeofday = dt.timedelta(hours=16)
    # Get a list of trading days between the start and the end.
    ldt_timestamps = du.getNYSEdays(ld_dates_unique[0], ld_dates_unique[-1] + dt.timedelta(days=1), dt_timeofday)
    # Creating an object of the dataaccess class with Yahoo as the source.
    c_dataobj = da.DataAccess('Yahoo')
    # Keys to be read from the data, it is good to read everything in one go.
    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']

    # Reading the data, now d_data is a dictionary with the keys above.
    # Timestamps and symbols are the ones that were specified before.
    ldf_data = c_dataobj.get_data(ldt_timestamps, ls_symbols_unique, ls_keys)
    d_data = dict(zip(ls_keys, ldf_data))

    # Filling the data for NAN
    for s_key in ls_keys:
        d_data[s_key] = d_data[s_key].fillna(method='ffill')
        d_data[s_key] = d_data[s_key].fillna(method='bfill')
        d_data[s_key] = d_data[s_key].fillna(1.0)

    # Getting the numpy ndarray of close prices.
    na_price = d_data['close'].values
    # create a trade matrix
    na_trade = np.zeros((len(ldt_timestamps), len(ls_symbols_unique)))

    # read the orders and fill in the trade shares
    reader = csv.reader(open(csvFile, 'rU'), delimiter=',')
    for row in reader:
        date_t = dt.datetime(int(row[0]), int(row[1]), int(row[2]), 16)
        symbol_t = row[3]
        operation_t = row[4]
        share_t = float(row[5])
        x_t = ldt_timestamps.index(date_t)
        y_t = ls_symbols_unique.index(symbol_t)
        if operation_t.upper() == 'BUY':
            na_trade[x_t, y_t] = na_trade[x_t, y_t] + share_t
        elif operation_t.upper() == 'SELL':
            na_trade[x_t, y_t] = na_trade[x_t, y_t] - share_t
        else:
            print 'Market operations in', csvFile, 'error!'

    # create holding matrix from trade matrix
    na_hold = np.zeros((len(ldt_timestamps), len(ls_symbols_unique)))
    for x in range(len(ldt_timestamps)):
        for y in range(len(ls_symbols_unique)):
            if x == 0:
                na_hold[x, y] = na_trade[x, y]
            else:
                na_hold[x, y] = na_trade[x, y] + na_hold[x-1, y]

    # calculate cash from the price and trade matrix
    na_cash = []
    for x in range(len(ldt_timestamps)):
        if x == 0:
            na_cash.append(initialMoney)
        else:
            na_cash.append(na_cash[x-1])

        for y in range(len(ls_symbols_unique)):
            na_cash[x] = na_cash[x] - na_price[x, y] * na_trade[x, y]

    # calculate portfolio value from price and holding matrix and cash
    na_portfolio = []
    for x in range(len(ldt_timestamps)):
        value_t = 0.0
        for y in range(len(ls_symbols_unique)):
            value_t = value_t + na_price[x, y] * na_hold[x, y]

        na_portfolio.append(value_t + na_cash[x])

    # write portfolio value to value.csv
    writer = csv.writer(open(valueFile, 'wb'), delimiter=',')
    for row in range(len(na_portfolio)):
        writer.writerow([ldt_timestamps[row].year, ldt_timestamps[row].month, ldt_timestamps[row].day, na_portfolio[row]])

if __name__ == '__main__':
    main()