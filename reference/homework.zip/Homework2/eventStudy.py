__author__ = 'humin_000'

# import pandas as pd
import numpy as np
# import math
import copy
import QSTK.qstkutil.qsdateutil as du
import datetime as dt
import QSTK.qstkutil.DataAccess as da
# import QSTK.qstkutil.tsutil as tsu
import QSTK.qstkstudy.EventProfiler as ep

def find_events(ls_symbols, d_data):
    ''' Finding the event dataframe '''
    df_close = d_data['actual_close']

    print "Finding Events"

    # Creating an empty dataframe
    df_events = copy.deepcopy(df_close)
    df_events = df_events * np.NAN

    # Time stamps for the event range
    ldt_timestamps = df_close.index
    count = 0

    for s_sym in ls_symbols:
        for i in range(1, len(ldt_timestamps)):
            # Calculating the returns for this timestamp
            f_symprice_today = df_close[s_sym].ix[ldt_timestamps[i]]
            f_symprice_yest = df_close[s_sym].ix[ldt_timestamps[i - 1]]

            # Event is found if price[t-1] >= 5.0 && price[t] < 5.0
            if f_symprice_today < 6.0 and f_symprice_yest >= 6.0:
                df_events[s_sym].ix[ldt_timestamps[i]] = 1
                count = count + 1

    return df_events, count

def main():
    dt_start = dt.datetime(2008, 1, 1)
    dt_end = dt.datetime(2009, 12, 31)
    ldt_timestamps = du.getNYSEdays(dt_start, dt_end, dt.timedelta(hours=16))

    c_dataobj = da.DataAccess('Yahoo')
    ls_symbols2008 = c_dataobj.get_symbols_from_list('sp5002008')
    ls_symbols2008.append('SPY')

    ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']
    ldf_data2008 = c_dataobj.get_data(ldt_timestamps, ls_symbols2008, ls_keys)
    d_data2008 = dict(zip(ls_keys, ldf_data2008))

    for s_key in ls_keys:
        d_data2008[s_key] = d_data2008[s_key].fillna(method='ffill')
        d_data2008[s_key] = d_data2008[s_key].fillna(method='bfill')
        d_data2008[s_key] = d_data2008[s_key].fillna(1.0)

    df_events2008, count2008 = find_events(ls_symbols2008, d_data2008)
    print "Creating Study 2008"
    ep.eventprofiler(df_events2008, d_data2008, i_lookback=20, i_lookforward=20,
                s_filename='MyEventStudy2008new.pdf', b_market_neutral=True, b_errorbars=True,
                s_market_sym='SPY')

    print "For the $6.0 event with S&P500 in 2008, we find", count2008, "events. Date Range = 1st Jan,2008 to 31st Dec, 2009."

    # ls_symbols2012 = c_dataobj.get_symbols_from_list('sp5002012')
    # ls_symbols2012.append('SPY')
    #
    # ls_keys = ['open', 'high', 'low', 'close', 'volume', 'actual_close']
    # ldf_data2012 = c_dataobj.get_data(ldt_timestamps, ls_symbols2012, ls_keys)
    # d_data2012 = dict(zip(ls_keys, ldf_data2012))
    #
    # for s_key in ls_keys:
    #     d_data2012[s_key] = d_data2012[s_key].fillna(method='ffill')
    #     d_data2012[s_key] = d_data2012[s_key].fillna(method='bfill')
    #     d_data2012[s_key] = d_data2012[s_key].fillna(1.0)
    #
    # df_events2012, count2012 = find_events(ls_symbols2012, d_data2012)
    # print "Creating Study 2012"
    # ep.eventprofiler(df_events2012, d_data2012, i_lookback=20, i_lookforward=20,
    #             s_filename='MyEventStudy2012.pdf', b_market_neutral=True, b_errorbars=True,
    #             s_market_sym='SPY')
    #
    # print "For the $5.0 event with S&P500 in 2012, we find", count2012, "events. Date Range = 1st Jan,2008 to 31st Dec, 2009."

if __name__ == '__main__':
    main()